ALERT_CONFIG ={
    "CRITICAL": {
        "SUBSCRIBED": {
            "Dharmpal": {
                "mobile": "8052632490",
                "email": "chaudharydharmpal95@gmail.com"
            }
        },
        "TYPES": ['phone', 'email', 'sms']
    },
    "INFO": {
        "SUBSCRIBED": {
            "mobile": "8052632490",
            "email": "chaudharydharmpal95@gmail.com"
        },
        "TYPES": ['phone', 'sms']
    },
    "BLOKER": {
        "SUBSCRIBED": {
            "mobile": "8052632490",
            "email": "chaudharydharmpal95@gmail.com"
        },
        "TYPES": ['phone', 'email']
    },
    "WARNING": {
        "SUBSCRIBED": {
            "mobile": "8052632490",
            "email": "chaudharydharmpal95@gmail.com"
        },
        "TYPES": ['phone']
    }
}