def call_user(mobile_number, things_to_be_said):
    print("Phone call has been done to the user : {} and with this message: {}".format(mobile_number, things_to_be_said))
    return True