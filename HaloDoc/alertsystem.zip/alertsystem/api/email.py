def send_email(to, emailContent):
    print("Email has been send to the user : {} and with this content: {}".format(to, emailContent))
    return True