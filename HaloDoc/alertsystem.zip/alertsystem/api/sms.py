def send_sms(mobile_number, text):
    print("SMS has been SENT to the user : {} and with this message: {}".format(mobile_number, text))
    return True