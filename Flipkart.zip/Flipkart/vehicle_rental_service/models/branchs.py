BRANCHES = {
    # branch_name, - [ {
    #     price
    #     count
    # }]
}

# Data will be in format that by passing branch name we should be getting branch obj

