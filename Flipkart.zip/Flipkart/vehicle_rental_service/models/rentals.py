RENTALS = {
    # branch, vehicle_type, bookings [from, to, price]
}


#Adding all rentals